<div class="page-inner">

    <div class="page-header">
        <h4 class="page-title">Jadwal</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="#">
                    <i class="flaticon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="#">Jadwal Perkuliahan</a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
        </ul>
    </div>

    <?php 
   // tampilkan data absen setiap bulan, berdasarkan tahun ajaran yg aktif
   $qry = mysqli_query($con,"SELECT * FROM mahasiswa
    INNER JOIN matkul ON mahasiswa.id_siswa=matkul.id_siswa
    INNER JOIN tb_mengajar ON matkul.id_mapel=tb_mengajar.id_mapel
    INNER JOIN dosen ON tb_mengajar.id_guru=dosen.id_guru
    INNER JOIN ruang_kelas ON tb_mengajar.id_mkelas=ruang_kelas.id_mkelas
    WHERE mahasiswa.id_siswa='$data[id_siswa]'");
 while ($tampil = mysqli_fetch_array($qry))
 
    foreach ($qry as $hari) { ?>
    <?php 
     $hari = date('m',strtotime($hari['hari']));

     ?>


    <div class="col-sm-12">
        <div class="alert alert-info alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
            <strong>
                <h3><?= $jd['tb_mengajar']; ?></h3>
            </strong>
            <hr>
            <ul>
                <li>
                    Hari : <?= $tampil['hari']; ?>
                </li>
                <li>
                    Jam Ke : <?= $tampil['jamke']; ?>
                </li>
                <li>
                    Waktu : <?= $tampil['jam_mengajar']; ?>
                </li>
                <li>
                    <?= $jd['ruang_kelas']; ?>
                    Kelas : <?= $tampil['nama_kelas']; ?>
                </li>
            </ul>
            <hr>
            <a href="?page=absen&pelajaran=<?= $jd['tb_mengajar'] ?> " class="btn btn-default btn-block text-left">
                <i class="fas fa-clipboard-check"></i>
                Presensi
            </a>
        </div>
    </div>
    <?php } ?>
</div>
</div>
</div>